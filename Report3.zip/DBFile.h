#include <stdio.h>

int dbCreate();
int dbQuery();
int dbUpdate();
