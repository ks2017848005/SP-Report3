#include "student.h"
#include "DBFile.h"

int main(){
	printf("1. DB Create\n");
	printf("2. DB Query\n");
	printf("3. DB Update\n");
	printf("0. Exit \n");
	
	int select;
	printf("��ȣ �Է� >> "); 
	scanf("%d", &select);

	while(select > 0){
		switch(select){
			case 1 :
				dbCreate();
				break;
			case 2 :
				dbQuery();
				break;
			case 3 :
				dbUpdate();
				break;
			case 0:
			default :
				printf("����\n");
				break;
		}
	}
}

