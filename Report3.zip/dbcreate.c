#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include "student.h"

/* �л� ������ �Է¹޾� �����ͺ��̽� ���Ͽ� �����Ѵ�. */
int dbCreate()
{
    int fd;
    struct student rec;
	/*
    if (argc < 2) {
        fprintf(stderr,  "���� : %s file\n", argv[0]);
        exit(1);
    }

    if ((fd = open(argv[1],O_WRONLY |O_CREAT, 0640))==-1) {
        perror(argv[1]);
        exit(2);
    }*/
    int count = 0;
    printf("Usage : [filename] \n");
    printf(">> ");
    
    char filename[20] = {0,};
    scanf("%s", &filename);

	
    if((fd = open(filename,O_WRONLY |O_CREAT, 0640))==-1){
    	perror(filename);
        exit(2);
	}

    printf("%-9s %-8s %-4s", "�й�",  "�̸�",  "����\n"); 
    while (scanf("%d %s %d", &rec.id, rec.name, &rec.score) == 3) {
        lseek(fd, (rec.id - START_ID) * sizeof(rec), SEEK_SET);
        write(fd, &rec, sizeof(rec) );
    }

    close(fd);
    exit(0);
}
